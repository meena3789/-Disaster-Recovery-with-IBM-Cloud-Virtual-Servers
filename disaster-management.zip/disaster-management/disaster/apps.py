from django.apps import AppConfig


class DisasterConfig(AppConfig):
    name = 'disaster'
