from django.contrib import admin

from .models import main,login,givealert

admin.site.register(main)

admin.site.register(login)

admin.site.register(givealert)



